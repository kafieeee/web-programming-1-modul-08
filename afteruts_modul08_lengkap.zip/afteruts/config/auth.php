<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (empty($_SESSION["login"])) {
    header("Location: ../pages/login.php");
    exit;
}
