<?php
require_once "../config/auth.php";
require_once "../config/koneksi.php";
if ($_SERVER["REQUEST_METHOD"] !== "POST") { header("Location: ../crud/index.php"); exit; }
$id = $_POST["id"] ?? "";
if (!ctype_digit((string)$id)) die("ID tidak valid.");
$stmt = mysqli_prepare($conn, "DELETE FROM mahasiswa WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
if (mysqli_stmt_execute($stmt)) { header("Location: ../crud/index.php?status=hapus"); exit; }
die("Gagal menghapus data: " . mysqli_error($conn));
