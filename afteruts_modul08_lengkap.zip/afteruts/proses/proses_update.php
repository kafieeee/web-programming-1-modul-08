<?php
require_once "../config/auth.php";
require_once "../config/koneksi.php";
if ($_SERVER["REQUEST_METHOD"] !== "POST") { header("Location: ../crud/index.php"); exit; }
$id = $_POST["id"] ?? "";
$nim = trim($_POST["nim"] ?? "");
$nama = trim($_POST["nama"] ?? "");
$prodi = trim($_POST["program_studi"] ?? "");
$email = trim($_POST["email"] ?? "");
if (!ctype_digit((string)$id) || $nim === "" || $nama === "" || $prodi === "" || $email === "") die("Data tidak valid atau belum lengkap.");
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) die("Format email tidak valid.");
$stmt = mysqli_prepare($conn, "UPDATE mahasiswa SET nim=?, nama=?, program_studi=?, email=? WHERE id=?");
mysqli_stmt_bind_param($stmt, "ssssi", $nim, $nama, $prodi, $email, $id);
if (mysqli_stmt_execute($stmt)) { header("Location: ../crud/index.php?status=update"); exit; }
die("Gagal mengubah data: " . mysqli_error($conn));
