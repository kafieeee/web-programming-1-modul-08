<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if ($_SERVER["REQUEST_METHOD"] !== "POST") { header("Location: ../pages/login.php"); exit; }
$username = trim($_POST["username"] ?? "");
$password = $_POST["password"] ?? "";
if ($username === "admin" && $password === "12345") {
    session_regenerate_id(true);
    $_SESSION["login"] = true;
    $_SESSION["username"] = $username;
    header("Location: ../pages/dashboard.php");
    exit;
}
header("Location: ../pages/login.php?error=1");
exit;
