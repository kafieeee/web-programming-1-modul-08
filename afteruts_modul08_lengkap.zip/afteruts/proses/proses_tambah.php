<?php
require_once "../config/auth.php";
require_once "../config/koneksi.php";
if ($_SERVER["REQUEST_METHOD"] !== "POST") { header("Location: ../pages/form_mahasiswa.php"); exit; }
$nim = trim($_POST["nim"] ?? "");
$nama = trim($_POST["nama"] ?? "");
$prodi = trim($_POST["program_studi"] ?? "");
$email = trim($_POST["email"] ?? "");
if ($nim === "" || $nama === "" || $prodi === "" || !filter_var($email, FILTER_VALIDATE_EMAIL)) die("Data tidak lengkap atau email tidak valid.");
$stmt = mysqli_prepare($conn, "INSERT INTO mahasiswa (nim,nama,program_studi,email) VALUES (?,?,?,?)");
mysqli_stmt_bind_param($stmt, "ssss", $nim, $nama, $prodi, $email);
if (!mysqli_stmt_execute($stmt)) die("Gagal menyimpan data.");
header("Location: ../pages/data_mahasiswa.php"); exit;
