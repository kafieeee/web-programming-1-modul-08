<?php
require_once "../config/auth.php";
require_once "../config/koneksi.php";
if ($_SERVER["REQUEST_METHOD"] !== "POST") { header("Location: ../crud/index.php"); exit; }
$nim = trim($_POST["nim"] ?? "");
$nama = trim($_POST["nama"] ?? "");
$prodi = trim($_POST["program_studi"] ?? "");
$email = trim($_POST["email"] ?? "");
if ($nim === "" || $nama === "" || $prodi === "" || $email === "") die("Semua kolom wajib diisi.");
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) die("Format email tidak valid.");
$stmt = mysqli_prepare($conn, "INSERT INTO mahasiswa (nim,nama,program_studi,email) VALUES (?,?,?,?)");
mysqli_stmt_bind_param($stmt, "ssss", $nim, $nama, $prodi, $email);
if (mysqli_stmt_execute($stmt)) { header("Location: ../crud/index.php?status=tambah"); exit; }
die("Gagal menyimpan data: " . mysqli_error($conn));
