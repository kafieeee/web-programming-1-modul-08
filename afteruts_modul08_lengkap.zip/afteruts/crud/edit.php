<?php
require_once "../config/auth.php";
require_once "../config/koneksi.php";
$id = $_GET["id"] ?? "";
if (!ctype_digit((string)$id)) die("ID tidak valid.");
$stmt = mysqli_prepare($conn, "SELECT id, nim, nama, program_studi, email FROM mahasiswa WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);
if (!$data) die("Data mahasiswa tidak ditemukan.");
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Edit Mahasiswa</title><link rel="stylesheet" href="../assets/css/style.css"></head><body>
<header class="topbar"><a class="brand" href="../pages/dashboard.php">WEB<span>PROGRAMMING</span></a><nav><a href="../pages/dashboard.php">Dashboard</a><a href="index.php">CRUD Mahasiswa</a><a href="../proses/logout.php">Logout</a></nav></header>
<main class="container narrow"><div class="page-heading"><div><p class="eyebrow">UPDATE</p><h1>Edit Mahasiswa</h1><p class="muted">Perbarui informasi mahasiswa.</p></div></div>
<section class="panel"><form action="../proses/proses_update.php" method="POST" class="crud-form" data-crud-form>
<input type="hidden" name="id" value="<?= (int)$data["id"]; ?>">
<label for="nim">NIM</label><input id="nim" name="nim" maxlength="20" value="<?= htmlspecialchars($data["nim"]); ?>" required>
<label for="nama">Nama</label><input id="nama" name="nama" maxlength="100" value="<?= htmlspecialchars($data["nama"]); ?>" required>
<label for="program_studi">Program Studi</label><input id="program_studi" name="program_studi" maxlength="100" value="<?= htmlspecialchars($data["program_studi"]); ?>" required>
<label for="email">Email</label><input id="email" type="email" name="email" maxlength="100" value="<?= htmlspecialchars($data["email"]); ?>" required>
<div class="form-actions"><button class="btn btn-primary" type="submit">Update Data</button><a class="btn btn-light" href="index.php">Batal</a></div></form></section></main>
<script src="../assets/js/crud.js"></script></body></html>
