<?php
require_once "../config/auth.php";
require_once "../config/koneksi.php";
$query = mysqli_query($conn, "SELECT id, nim, nama, program_studi, email FROM mahasiswa ORDER BY id DESC");
if (!$query) die("Gagal mengambil data: " . mysqli_error($conn));
?>
<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>CRUD Mahasiswa</title><link rel="stylesheet" href="../assets/css/style.css"></head><body>
<header class="topbar"><a class="brand" href="../pages/dashboard.php">WEB<span>PROGRAMMING</span></a><nav><a href="../pages/dashboard.php">Dashboard</a><a href="../pages/index.php">Beranda</a><a href="../pages/layout.php">Layout</a><a href="../pages/data_mahasiswa.php">Data Mahasiswa</a><a href="../pages/form_mahasiswa.php">Tambah Mahasiswa</a><a class="active" href="index.php">CRUD Mahasiswa</a><a href="../proses/logout.php">Logout</a></nav></header>
<main class="container">
<div class="page-heading"><div><p class="eyebrow">PENGELOLAAN DATA</p><h1>CRUD Mahasiswa</h1><p class="muted">Kelola data mahasiswa melalui operasi tambah, baca, edit, dan hapus.</p></div><a class="btn btn-primary" href="tambah.php">+ Tambah Mahasiswa</a></div>
<div class="panel">
<div class="crud-toolbar"><div><h2>Daftar Mahasiswa</h2><p class="muted">Data terbaru ditampilkan lebih dahulu.</p></div><input id="cariMahasiswa" type="search" placeholder="Cari NIM, nama, prodi, email..."></div>
<?php if (isset($_GET["status"])): ?><div class="alert alert-success" id="statusMessage"><?php
$messages = ["tambah"=>"Data mahasiswa berhasil ditambahkan.", "update"=>"Data mahasiswa berhasil diperbarui.", "hapus"=>"Data mahasiswa berhasil dihapus."];
echo htmlspecialchars($messages[$_GET["status"]] ?? "Proses selesai.");
?></div><?php endif; ?>
<div class="table-wrap"><table id="tabelMahasiswa"><thead><tr><th>ID</th><th>NIM</th><th>Nama</th><th>Program Studi</th><th>Email</th><th>Aksi</th></tr></thead><tbody>
<?php if (mysqli_num_rows($query) === 0): ?><tr><td colspan="6" class="empty-state">Belum ada data mahasiswa.</td></tr><?php endif; ?>
<?php while ($data = mysqli_fetch_assoc($query)): ?><tr>
<td><?= (int)$data["id"]; ?></td><td><?= htmlspecialchars($data["nim"]); ?></td><td><?= htmlspecialchars($data["nama"]); ?></td><td><?= htmlspecialchars($data["program_studi"]); ?></td><td><?= htmlspecialchars($data["email"]); ?></td>
<td><div class="actions"><a class="btn btn-small btn-light" href="edit.php?id=<?= (int)$data["id"]; ?>">Edit</a>
<form class="delete-form" action="../proses/proses_hapus.php" method="POST" data-delete-form><input type="hidden" name="id" value="<?= (int)$data["id"]; ?>"><button class="btn btn-small btn-danger" type="submit">Hapus</button></form></div></td>
</tr><?php endwhile; ?></tbody></table></div></div></main>
<script src="../assets/js/crud.js"></script></body></html>
