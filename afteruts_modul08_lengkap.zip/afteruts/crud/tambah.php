<?php require_once "../config/auth.php"; ?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Tambah Mahasiswa</title><link rel="stylesheet" href="../assets/css/style.css"></head><body>
<header class="topbar"><a class="brand" href="../pages/dashboard.php">WEB<span>PROGRAMMING</span></a><nav><a href="../pages/dashboard.php">Dashboard</a><a href="index.php">CRUD Mahasiswa</a><a href="../proses/logout.php">Logout</a></nav></header>
<main class="container narrow"><div class="page-heading"><div><p class="eyebrow">CREATE</p><h1>Tambah Mahasiswa</h1><p class="muted">Isi seluruh data mahasiswa dengan benar.</p></div></div>
<section class="panel"><form action="../proses/proses_crud_tambah.php" method="POST" class="crud-form" data-crud-form>
<label for="nim">NIM</label><input id="nim" type="text" name="nim" maxlength="20" required>
<label for="nama">Nama</label><input id="nama" type="text" name="nama" maxlength="100" required>
<label for="program_studi">Program Studi</label><input id="program_studi" type="text" name="program_studi" maxlength="100" required>
<label for="email">Email</label><input id="email" type="email" name="email" maxlength="100" required>
<div class="form-actions"><button class="btn btn-primary" type="submit">Simpan Data</button><a class="btn btn-light" href="index.php">Kembali</a></div></form></section></main>
<script src="../assets/js/crud.js"></script></body></html>
