# Web Programming 1 - Modul 08

Aplikasi latihan Form Handling, Validation & CRUD menggunakan PHP, MySQL, dan JavaScript.

## Cara menjalankan
1. Ekstrak folder `afteruts` ke `C:\laragon\www\`.
2. Buka Laragon lalu klik **Start All**.
3. Buka `http://localhost/phpmyadmin`.
4. Pilih menu **Import**, pilih `afteruts/database/database.sql`, lalu klik **Go**. Alternatif: buka file SQL dan jalankan melalui tab SQL.
5. Buka `http://localhost/afteruts/`.
6. Login dengan username `admin` dan password `12345`.

## Fitur
- Login dan logout berbasis session.
- Dashboard dan halaman data mahasiswa.
- CRUD mahasiswa: tambah, lihat, edit, hapus.
- Validasi form di browser dan di PHP.
- Prepared statement untuk operasi database.
- Pencarian data di tabel dengan JavaScript.
- Konfirmasi sebelum menghapus data.

## Konfigurasi database
Pengaturan database ada di `config/koneksi.php`. Default Laragon:
- Host: `localhost`
- User: `root`
- Password: kosong
- Database: `web_programming_1`

Jika MySQL kamu menggunakan password, ubah variabel `$password`.

## Catatan
Akun `admin / 12345` adalah akun demo praktikum, bukan untuk aplikasi produksi.
