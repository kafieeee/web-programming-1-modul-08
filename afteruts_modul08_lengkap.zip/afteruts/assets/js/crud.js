document.addEventListener("DOMContentLoaded", function () {
    // Validasi form di sisi browser
    document.querySelectorAll("[data-crud-form]").forEach(function (form) {
        form.addEventListener("submit", function (event) {
            let valid = true;
            form.querySelectorAll("input[required]").forEach(function (input) {
                input.classList.remove("is-invalid");
                if (!input.value.trim() || !input.checkValidity()) {
                    input.classList.add("is-invalid");
                    valid = false;
                }
            });
            if (!valid) {
                event.preventDefault();
                alert("Periksa kembali data. Semua kolom wajib diisi dan email harus valid.");
            }
        });
    });

    // Konfirmasi sebelum menghapus data
    document.querySelectorAll("[data-delete-form]").forEach(function (form) {
        form.addEventListener("submit", function (event) {
            if (!confirm("Yakin ingin menghapus data mahasiswa ini?")) {
                event.preventDefault();
            }
        });
    });

    // Pencarian langsung pada tabel
    const search = document.getElementById("cariMahasiswa");
    const table = document.getElementById("tabelMahasiswa");
    if (search && table) {
        search.addEventListener("input", function () {
            const keyword = search.value.toLowerCase();
            table.querySelectorAll("tbody tr").forEach(function (row) {
                row.style.display = row.textContent.toLowerCase().includes(keyword) ? "" : "none";
            });
        });
    }
});
