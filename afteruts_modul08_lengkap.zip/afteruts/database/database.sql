CREATE DATABASE IF NOT EXISTS web_programming_1
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE web_programming_1;

CREATE TABLE IF NOT EXISTS mahasiswa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nim VARCHAR(20) NOT NULL,
    nama VARCHAR(100) NOT NULL,
    program_studi VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL
);

-- Contoh data awal (jalankan sekali jika tabel masih kosong)
INSERT INTO mahasiswa (nim, nama, program_studi, email)
SELECT '123456', 'Muhammad Fajri Alkafi', 'Informatika', 'kafi@gmail.com'
WHERE NOT EXISTS (SELECT 1 FROM mahasiswa LIMIT 1);
