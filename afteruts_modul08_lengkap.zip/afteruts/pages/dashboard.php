<?php
require_once "../config/auth.php";
require_once "../config/koneksi.php";
$totalResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM mahasiswa");
$total = mysqli_fetch_assoc($totalResult)["total"] ?? 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard | Web Programming 1</title><link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<header class="topbar"><a class="brand" href="dashboard.php">WEB<span>PROGRAMMING</span></a>
<nav><a class="active" href="dashboard.php">Dashboard</a><a href="data_mahasiswa.php">Data Mahasiswa</a><a href="../crud/index.php">CRUD Mahasiswa</a><a href="../proses/logout.php">Logout</a></nav></header>
<main class="container">
<section class="hero"><p class="eyebrow">HALO, <?= htmlspecialchars($_SESSION["username"] ?? "Admin"); ?></p>
<h1>Dashboard</h1><p class="muted">Selamat datang di aplikasi pengelolaan data mahasiswa.</p></section>
<section class="stats-grid"><article class="stat-card"><span>Total Mahasiswa</span><strong><?= (int)$total; ?></strong><small>Data tersimpan di database</small></article>
<article class="stat-card"><span>Modul Praktikum</span><strong>08</strong><small>Form Handling, Validation & CRUD</small></article></section>
<section class="panel"><h2>Menu utama</h2><div class="menu-grid">
<a class="menu-card" href="data_mahasiswa.php"><b>Data Mahasiswa</b><span>Lihat daftar mahasiswa</span></a>
<a class="menu-card" href="form_mahasiswa.php"><b>Tambah Mahasiswa</b><span>Form tambah versi sebelumnya</span></a>
<a class="menu-card" href="../crud/index.php"><b>CRUD Mahasiswa</b><span>Tambah, baca, edit, dan hapus data</span></a>
</div></section>
</main>
</body></html>
