<?php
require_once "../config/auth.php";
require_once "../config/koneksi.php";
$result = mysqli_query($conn, "SELECT * FROM mahasiswa ORDER BY id DESC");
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Data Mahasiswa</title><link rel="stylesheet" href="../assets/css/style.css"></head><body>
<header class="topbar"><a class="brand" href="dashboard.php">WEB<span>PROGRAMMING</span></a><nav><a href="dashboard.php">Dashboard</a><a class="active" href="data_mahasiswa.php">Data Mahasiswa</a><a href="../crud/index.php">CRUD Mahasiswa</a><a href="../proses/logout.php">Logout</a></nav></header>
<main class="container"><div class="page-heading"><div><p class="eyebrow">DATA</p><h1>Data Mahasiswa</h1></div><a class="btn btn-primary" href="form_mahasiswa.php">+ Tambah Mahasiswa</a></div>
<div class="panel table-wrap"><table><thead><tr><th>ID</th><th>NIM</th><th>Nama</th><th>Program Studi</th><th>Email</th></tr></thead><tbody>
<?php while ($row = mysqli_fetch_assoc($result)): ?><tr><td><?= (int)$row["id"]; ?></td><td><?= htmlspecialchars($row["nim"]); ?></td><td><?= htmlspecialchars($row["nama"]); ?></td><td><?= htmlspecialchars($row["program_studi"]); ?></td><td><?= htmlspecialchars($row["email"]); ?></td></tr><?php endwhile; ?>
</tbody></table></div></main></body></html>
