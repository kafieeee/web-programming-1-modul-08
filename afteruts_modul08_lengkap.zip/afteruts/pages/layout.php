<?php require_once "../config/auth.php"; ?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><title>Layout</title><link rel="stylesheet" href="../assets/css/style.css"></head><body>
<header class="topbar"><a class="brand" href="dashboard.php">WEB<span>PROGRAMMING</span></a><nav><a href="dashboard.php">Dashboard</a><a href="data_mahasiswa.php">Data Mahasiswa</a><a href="../crud/index.php">CRUD Mahasiswa</a><a href="../proses/logout.php">Logout</a></nav></header>
<main class="container"><section class="hero"><h1>Layout Aplikasi</h1><p class="muted">Halaman layout dasar aplikasi Web Programming 1.</p></section></main></body></html>
