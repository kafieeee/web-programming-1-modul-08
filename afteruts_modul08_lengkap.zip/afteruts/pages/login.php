<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!empty($_SESSION["login"])) {
    header("Location: dashboard.php");
    exit;
}
$error = $_GET["error"] ?? "";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Web Programming 1</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="login-page">
<main class="login-card">
    <div class="brand-mark">WP</div>
    <p class="eyebrow">WEB PROGRAMMING 1</p>
    <h1>Selamat datang</h1>
    <p class="muted">Masuk untuk mengelola data mahasiswa.</p>
    <?php if ($error): ?><div class="alert alert-error">Username atau password salah.</div><?php endif; ?>
    <form action="../proses/proses_login.php" method="POST" class="crud-form">
        <label for="username">Username</label>
        <input id="username" type="text" name="username" placeholder="Masukkan username" required>
        <label for="password">Password</label>
        <input id="password" type="password" name="password" placeholder="Masukkan password" required>
        <button class="btn btn-primary btn-block" type="submit">Login</button>
    </form>
    <p class="login-hint">Akun demo: <b>admin</b> / <b>12345</b></p>
</main>
</body>
</html>
