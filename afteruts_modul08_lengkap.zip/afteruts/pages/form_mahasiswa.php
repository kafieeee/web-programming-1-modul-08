<?php require_once "../config/auth.php"; ?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Tambah Mahasiswa</title><link rel="stylesheet" href="../assets/css/style.css"></head><body>
<header class="topbar"><a class="brand" href="dashboard.php">WEB<span>PROGRAMMING</span></a><nav><a href="dashboard.php">Dashboard</a><a href="data_mahasiswa.php">Data Mahasiswa</a><a href="../crud/index.php">CRUD Mahasiswa</a><a href="../proses/logout.php">Logout</a></nav></header>
<main class="container narrow"><div class="page-heading"><div><p class="eyebrow">FORM LAMA</p><h1>Tambah Mahasiswa</h1></div></div>
<section class="panel"><form action="../proses/proses_tambah.php" method="POST" class="crud-form" data-crud-form>
<label>NIM</label><input name="nim" required maxlength="20">
<label>Nama</label><input name="nama" required maxlength="100">
<label>Program Studi</label><input name="program_studi" required maxlength="100">
<label>Email</label><input type="email" name="email" required maxlength="100">
<div class="form-actions"><button class="btn btn-primary" type="submit">Simpan</button><a class="btn btn-light" href="data_mahasiswa.php">Kembali</a></div></form></section></main>
<script src="../assets/js/crud.js"></script></body></html>
